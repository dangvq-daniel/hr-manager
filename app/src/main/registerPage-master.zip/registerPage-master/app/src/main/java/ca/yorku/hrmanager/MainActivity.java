package ca.yorku.hrmanager;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.util.Patterns;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;



public class MainActivity extends AppCompatActivity {

    private Button registers;
    private EditText editTextEmail, editTextPassword;
    private Button signIn;

    @Override
    protected void onCreate(Bundle savedInstanceState) {//save the data in savedInstanceState
        super.onCreate(savedInstanceState); //passed back to onCreate if activity crash and needs to be recreated
        setContentView(R.layout.activity_main); //show activity design in activity_register_user.xml

        registers = (Button) findViewById(R.id.register);// go to register page.
        registers.setOnClickListener(new View.OnClickListener() {

            @Override
            public void onClick(View v) { //if user click register button then page switch to register page.
                Intent intent = new Intent(MainActivity.this, register_user.class);
                startActivity(intent);
            }
        });

        editTextEmail = (EditText) findViewById(R.id.email);
        editTextPassword = (EditText) findViewById(R.id.password);

        signIn = (Button) findViewById(R.id.signIn); // signin to dashboard
        signIn.setOnClickListener(new View.OnClickListener() {

        @Override
        public void onClick(View v) {
            switch (v.getId()) {
                case R.id.register:
                    startActivity(new Intent(MainActivity.this, register_user.class));
                    break;

                case R.id.signIn:
                    userLogin(); //if user login initiated userLogin method.
                    break;
            }
        }
    });
                }

    private void userLogin() {

        String email = editTextEmail.getText().toString();
        String password = editTextPassword.getText().toString();

        if (email.isEmpty()) {
            editTextEmail.setError("Please enter your email");
            editTextEmail.requestFocus();
            return;
        }
        if (password.isEmpty()) {
            editTextPassword.setError("Please enter your password");
            editTextPassword.requestFocus();
            return;
        }

        if (!Patterns.EMAIL_ADDRESS.equals(email)) { //if user provides wrong type of email address ask again
            editTextEmail.setError("Please provide valid email");
            editTextEmail.requestFocus();
            return;
        }

    }
}
