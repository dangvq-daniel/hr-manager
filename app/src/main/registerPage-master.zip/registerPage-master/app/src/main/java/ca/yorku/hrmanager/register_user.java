package ca.yorku.hrmanager;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.util.Patterns;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;

public class register_user extends AppCompatActivity {

    private TextView banner;
    private Button registerUsers;
    private EditText editTextFullName, editTextENumber, editTextEmail, editTextPassword;

    @Override
    protected void onCreate(Bundle savedInstanceState) { //save the data in savedInstanceState
        super.onCreate(savedInstanceState); //passed back to onCreate if activity crash and needs to be recreated
        setContentView(R.layout.activity_register_user); //show activity design in activity_register_user.xml


        editTextFullName = (EditText) findViewById(R.id.fullName);
        editTextENumber = (EditText) findViewById(R.id.eNumber);
        editTextEmail = (EditText) findViewById(R.id.email);
        editTextPassword = (EditText) findViewById(R.id.password);


        registerUsers = (Button) findViewById(R.id.registerUser);// go to register page.
        registerUsers.setOnClickListener(new View.OnClickListener() {

            @Override
            public void onClick(View v) {
                switch (v.getId()) {//once id clicked switch
                    case R.id.banner:
                        startActivity(new Intent(register_user.this, register_user.class)); //redirect to main page
                        break;

                    case R.id.registerUser: //if resource id is registerUser then call registerUser method
                        registerUsers();
                        break;
                }
            }
        });}

            private void registerUsers() {

                String fullName = editTextFullName.getText().toString();
                String eNumber = editTextENumber.getText().toString();
                String email = editTextEmail.getText().toString();
                String password = editTextPassword.getText().toString();

                if (fullName.isEmpty()) {
                    editTextFullName.setError("Please enter full name");
                    editTextFullName.requestFocus();
                    return;
                }

                if (eNumber.isEmpty()) {
                    editTextENumber.setError("Please enter employee number");
                    editTextENumber.requestFocus();
                    return;
                }

                if (email.isEmpty()) {
                    editTextEmail.setError("Please enter your email");
                    editTextEmail.requestFocus();
                    return;
                }

                if (!Patterns.EMAIL_ADDRESS.equals(email)) { //if user provides wrong type of email address ask again
                    editTextEmail.setError("Please provide valid email");
                    editTextEmail.requestFocus();
                    return;
                }

                if (password.isEmpty()) {
                    editTextPassword.setError("Password is required");
                    editTextPassword.requestFocus();
                    return;
                }

                if (password.length() < 10) {
                    editTextPassword.setError("Min password length should be 6 characters");
                    editTextPassword.requestFocus();
                    return;

                }

            }
        }
